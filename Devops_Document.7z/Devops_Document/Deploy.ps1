cd $env:system_directory\_CashinDB\Deployment\
$Text = Get-Content -path $env:system_directory\_CashinDB\Deployment\Deploy.ctl
 If (!$Text)
    {
    exit 0;
    }
$Text.GetType() | Format-Table -AutoSize


foreach($line in $text) 
{

    cd $line
   
    
    $text2 = 'set long 2000000000 longchunksize 2000000000 pagesize 0 linesize 1000 trimspool on'
    $text2 | Set-Content 'Deploy_New.ctl' 
    $text2 = 'WHENEVER OSERROR EXIT SQL.SQLCODE;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'WHENEVER SQLERROR EXIT SQL.SQLCODE;'
    $text2 | Add-Content 'Deploy_New.ctl'
    #$text2 = 'ALTER SESSION SET CURRENT_SCHEMA='+$line+';'
    #$text2 | Add-Content 'Deploy_KP_New.ctl'
    $text2 = 'column dt new_val X'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'select to_char(sysdate,''YYYYMMfmDDfm_HHMISS_AM'') dt from dual;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'SPOOL PG_' +$line + '_&X..log'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'set define off echo on'
    $text2 | Add-Content 'Deploy_New.ctl' 
    $text2 = 'DEF;'
    $text2 | Add-Content 'Deploy_New.ctl'
    #$text2 = 'select ''Current user switeched : '' || sys_context( ''userenv'', ''current_schema'' ) "User" from dual;'
    #$text2 | Add-Content 'Deploy_KP_New.ctl'
    #$text2 = 'Select ''Pre Deployment user objects : '' || Count(1) from user_objects;'
    #$text2 | Add-Content 'Deploy_KP_New.ctl'
    $text2 = 'select ''Pre Deployment Invalid objects for user : '' ||sys_context( ''userenv'', ''current_schema'' ) from dual;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'select object_name,object_type from user_objects where status=''INVALID'' ;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'set timing on'
    $text2 | Add-Content 'Deploy_New.ctl' 
    $text2 = Get-Content -path Deploy.ctl
    $text2 | Add-Content 'Deploy_New.ctl' 
    $text2 = 'set timing off'
    $text2 | Add-Content 'Deploy_New.ctl' 
    $text2 = 'Select ''Post Deployment user objects : '' || Count(1) from user_objects;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'select ''Post Deployment Invalid objects for user : '' ||sys_context( ''userenv'', ''current_schema'' ) from dual;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'select object_name,object_type from user_objects where status=''INVALID'';'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'spool off'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'exit'
    $text2 | Add-Content 'Deploy_New.ctl'
	 
	
##to resolve error --> Unable to find type [System.Web.HttpUtility] 
        Add-Type -AssemblyName System.Web
        write-host "Started PROD Deployment Process"
        ## invoke REST API to get arcos web service details
        write-host "Start REST API Invoke"
        $ipAdd = (Get-NetAdapter | Get-NetIPAddress | ? addressfamily -eq 'IPV4').IPAddress
        $txnDatetime = [Math]::Round((Get-Date).ToFileTime() / 10000000 - 11644473600) * 1000;
        $msg="<request><header><msg_code>RequestArcosService</msg_code><source>VSTS</source><channel>ALL</channel><txn_ref_number>VSTS_ALL_$txnDatetime</txn_ref_number><txn_datetime>$txnDatetime</txn_datetime><ip>$ipAdd</ip><device_id></device_id></header><detail><service_type>OracleQA</service_type><server_ip>10.240.55.99</server_ip><username>cashkotak</username><db_instance_name>fcm</db_instance_name><filler1></filler1><filler2></filler2><filler3></filler3><filler4></filler4><filler5></filler5></detail></request>";
        $requestMsg = [System.Web.HttpUtility]::UrlEncode($msg);
        $uri = "http://"+"$ipAdd"+":9080/arcos-service/RequestArcosService?format=xml&data=$requestMsg"
        write-host $uri
        $response = Invoke-RestMethod -Uri $uri -Method GET -ContentType "application/xml"
        [System.Xml.XmlElement] $root = $response.get_DocumentElement();
        $respStatusCode = $root.status_code
        $respStatusMessage = $root.status_msg
        $respResponseDatetime = $root.response_datetime
        $respArcosServiceData = $root.data.arcos_service_data

        write-host "StatusCode: $respStatusCode"
        write-host "StatusMessage: $respStatusMessage"
        write-host "ResponseDatetime: $respResponseDatetime"
        write-host "End REST API Invoke"
  if ($respStatusCode -eq 0)
  {
      sqlplus cashkotak/$respArcosServiceData@//10.240.55.99:1530/fcm "@Deploy_New.ctl"
     
    echo $LASTEXITCODE
    if ($LASTEXITCODE -ne 0 )
    { 
    write-host error;
    # Writes an error to the build summary and the log with details about the error
    Write-Error "$("the Write-Error PowerShell command reported that") $($env:ErrorMessage)"
    # Writes an error to the build summary and to the log in red text
    Write-Host  "$("##vso[task.LogIssue type=error;]") $("the task.LogIssue Azure Pipelines logging command reported that") $($env:ErrorMessage)"
    exit $LASTEXITCODE;
    }
    else
    { 
    write-host ok;
    }
  }
    

    cd ..
} 
