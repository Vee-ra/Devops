$cmdOutput = C:\ArcosUATAPI\Arcos_GetTargetPassword.exe "http://arcosuat.kotak.int:9095/arcosapi001.asmx" "https://arcosuat.kotak.int/ARCOSWebAPI/ARCOSWebDT.asmx" "ARCOSGWPWAPI@2013@Test--1" "10.10.47.120" "SSHLINUX" "wasadmin" "KOTAK UAT" " "




cmd.exe /c echo y | c:\putty\pscp.exe -scp -r -pw $cmdOutput $env:system_directory\_#{build}#\drop\* wasadmin@10.10.47.120:/app/IBM/FCMS/WAR_FILE


cmd.exe /c echo y | c:\putty\pscp.exe -scp -r -pw $cmdOutput $env:system_directory\_Scripts\Application\Dev\FCMS.py wasadmin@10.10.47.120:/app/IBM/FCMS/PYTHON_PATH

Start-Sleep -m 10000

#cmd.exe /c echo y | c:\putty\plink.exe -v -ssh 10.10.46.208 -l wasadmin -pw $cmdOutput /app/IBM/WebSphere/AppServer/profiles/Nach03/bin/wsadmin.sh -user monitor -password monitor@123 -lang jython -f /app/IBM/WebSphere/NACH/PYTHON_PATH/Nach.py KOTAK-JGPS-india-NACH-P2-20220413-UAT_war nach KOTAK-JGPS-india-NACH-P2-20220413-UAT.war KOTAK-JGPS-india-NACH-P2-20220413-UAT.war
#------------------------------------------------------------------------------
#cmd.exe /c echo y | c:\putty\plink.exe -v -ssh 10.10.46.208 -l wasadmin -pw $cmdOutput /app/IBM/WebSphere/AppServer/profiles/NACH03/installedApps/Dmgr_Cell01/bin/wsadmin.sh -user monitor -password monitor@123 -lang jython -f app/IBM/WebSphere/NACH/PYTHON_PATH/Nach.py KOTAK-JGPS-india-NACH-P2-20220413-UAT_war nach KOTAK-JGPS-india-NACH-P2-20220413-UAT.war KOTAK-JGPS-india-NACH-P2-20220413-UAT.war
#cmd.exe /c echo y | c:\putty\plink.exe -v -ssh 10.10.47.190 -l wasadmin -pw $cmdOutput /app/IBM/WebSphere/AppServer/profiles/COL1/bin/wsadmin.sh -user wasadmin -password wasadmin@123 -lang jython -f /app/IBM/CSF_VSTS/python_file/csfwebuat1.py csf csfweb csf.ear csfweb.war
