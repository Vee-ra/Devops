
cd env:system_directory\_CashinDB\Deployment\
$Text = Get-Content -path env:system_directory\_CashinDB\Deployment\
 If (!$Text)
    {
    exit 0;
    }
$Text.GetType() | Format-Table -AutoSize


foreach($line in $text) 
{

    cd $line

    $Text1 = Get-Content -path Deploy.ctl
      If (!$Text1)
    {
    continue;
    }
    $Text1.GetType() | Format-Table -AutoSize

    foreach($line1 in $text1) 
    {

        If ($line1.Contains("PackageBodies"))
        {
            $type  = 'PACKAGE'
        }
        elseIf ($line1.Contains("Procedures"))
        {
            $type  = 'PROCEDURE'
        }
        elseIf ($line1.Contains("Functions"))
        {
            $type  = 'FUNCTION'
        }
        elseIf ($line1.Contains("Triggers"))
        {
            $type  = 'TRIGGER'
        }
        elseIf ($line1.Contains("Views"))
        {
            $type  = 'VIEW'
        }
        elseIf ($line1.Contains("Types"))
        {
            $type  = 'TYPE'
        }
        Else
        {
            $type  = ''
        }
        echo $type
        If ($line1.Contains("PackageBodies") -Or $line1.Contains("Procedures") -Or $line1.Contains("Functions") -Or $line1.Contains("Triggers") -Or $line1.Contains("Views") -Or $line1.Contains("Types"))
        {
            $line1 = $line1.replace('@','')
            $line1 = $line1.replace('Procedures\','')
            $line1 = $line1.replace('PackageBodies\','')
            $line1 = $line1.replace('Functions\','')
            $line1 = $line1.replace('Triggers\','')
            $line1 = $line1.replace('Views\','')
            $line1 = $line1.replace('Types\','')
            $line1 = $line1.replace('.sql','')
            $line1 = $line1.replace('.SQL','')
            echo $line1

            

            #write-host "password: $password"

            $text2 = 'set long 2000000000 longchunksize 2000000000 pagesize 0 linesize 1000 feedback off verify off trimspool on'
            $text2 | Set-Content 'Generate.ctl'
            $text2 = 'column ddl format a1000'
            $text2 | Add-Content 'Generate.ctl' 
            $text2 = 'begin'
            $text2 | Add-Content 'Generate.ctl'
            $text2 = '   dbms_metadata.set_transform_param (dbms_metadata.session_transform, ''SQLTERMINATOR'', true);'
            $text2 | Add-Content 'Generate.ctl'
            $text2 = '   dbms_metadata.set_transform_param (dbms_metadata.session_transform, ''PRETTY'', true);'
            $text2 | Add-Content 'Generate.ctl'
            $text2 = 'end;'
            $text2 | Add-Content 'Generate.ctl'
            $text2 = '/'
            $text2 | Add-Content 'Generate.ctl'
            $text2 = 'DEF;'
            $text2 | Add-Content 'Generate.ctl' 
            $text2 = 'column dt new_val X'
            $text2 | Add-Content 'Generate.ctl'
            $text2 = 'select to_char(sysdate,''YYYYMMfmDDfm_HHMISS_AM'') dt from dual;'
            $text2 | Add-Content 'Generate.ctl' 
            $text2 = 'spool D:\Cashin_DB_Backup\'+ $line1 +'_&X..sql'
            $text2 | Add-Content 'Generate.ctl'
            $text2 = 'Select DBMS_METADATA.get_ddl ('''+$type+''', '''+$line1+''') from dual;'
            $text2 | Add-Content 'Generate.ctl'
            $text2 = 'spool off'
            $text2 | Add-Content 'Generate.ctl'
            $text2 = 'exit'
            $text2 | Add-Content 'Generate.ctl'

        ##to resolve error --> Unable to find type [System.Web.HttpUtility] 
        Add-Type -AssemblyName System.Web
        write-host "Started PROD Deployment Process"
        ## invoke REST API to get arcos web service details
        write-host "Start REST API Invoke"
        $ipAdd = (Get-NetAdapter | Get-NetIPAddress | ? addressfamily -eq 'IPV4').IPAddress
        $txnDatetime = [Math]::Round((Get-Date).ToFileTime() / 10000000 - 11644473600) * 1000;
        $msg="<request><header><msg_code>RequestArcosService</msg_code><source>VSTS</source><channel>ALL</channel><txn_ref_number>VSTS_ALL_$txnDatetime</txn_ref_number><txn_datetime>$txnDatetime</txn_datetime><ip>$ipAdd</ip><device_id></device_id></header><detail><service_type>OracleQA</service_type><server_ip>10.240.55.99</server_ip><username>cashkotak</username><db_instance_name>fcm</db_instance_name><filler1></filler1><filler2></filler2><filler3></filler3><filler4></filler4><filler5></filler5></detail></request>";
        $requestMsg = [System.Web.HttpUtility]::UrlEncode($msg);
        $uri = "http://"+"$ipAdd"+":9080/arcos-service/RequestArcosService?format=xml&data=$requestMsg"
        write-host $uri
        $response = Invoke-RestMethod -Uri $uri -Method GET -ContentType "application/xml"
        [System.Xml.XmlElement] $root = $response.get_DocumentElement();
        $respStatusCode = $root.status_code
        $respStatusMessage = $root.status_msg
        $respResponseDatetime = $root.response_datetime
        $respArcosServiceData = $root.data.arcos_service_data

        write-host "StatusCode: $respStatusCode"
        write-host "StatusMessage: $respStatusMessage"
        write-host "ResponseDatetime: $respResponseDatetime"
        write-host "End REST API Invoke"
        if ($respStatusCode -eq 0)
     {
          sqlplus -s cashkotak/$respArcosServiceData@//10.240.55.99:1530/fcm "@Generate.ctl"
     }
            

        }
    }
    cd ..
} 
