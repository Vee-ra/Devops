cd $env:system_directory\_CashinDB\Deployment\
$Text = Get-Content -path $env:system_directory\_CashinDB\Deployment\Deploy.ctl
 If (!$Text)
    {
    exit 0;
    }
$Text.GetType() | Format-Table -AutoSize


foreach($line in $text) 
{

    cd $line
   
    
    $text2 = 'set long 2000000000 longchunksize 2000000000 pagesize 0 linesize 1000 trimspool on'
    $text2 | Set-Content 'Deploy_New.ctl' 
    $text2 = 'WHENEVER OSERROR EXIT SQL.SQLCODE;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'WHENEVER SQLERROR EXIT SQL.SQLCODE;'
    $text2 | Add-Content 'Deploy_New.ctl'
    #$text2 = 'ALTER SESSION SET CURRENT_SCHEMA='+$line+';'
    #$text2 | Add-Content 'Deploy_KP_New.ctl'
    $text2 = 'column dt new_val X'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'select to_char(sysdate,''YYYYMMfmDDfm_HHMISS_AM'') dt from dual;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'SPOOL FAPLUS_&X..log'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'set define off echo on'
    $text2 | Add-Content 'Deploy_New.ctl' 
    $text2 = 'DEF;'
    $text2 | Add-Content 'Deploy_New.ctl'
    #$text2 = 'select ''Current user switeched : '' || sys_context( ''userenv'', ''current_schema'' ) "User" from dual;'
    #$text2 | Add-Content 'Deploy_KP_New.ctl'
    #$text2 = 'Select ''Pre Deployment user objects : '' || Count(1) from user_objects;'
    #$text2 | Add-Content 'Deploy_KP_New.ctl'
    $text2 = 'select ''Pre Deployment Invalid objects for user : '' ||sys_context( ''userenv'', ''current_schema'' ) from dual;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'select object_name,object_type from user_objects where status=''INVALID'' ;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'set timing on'
    $text2 = 'set serveroutput on'
    $text2 | Add-Content 'Deploy_New.ctl' 
    $text2 = Get-Content -path Deploy.ctl
    $text2 | Add-Content 'Deploy_New.ctl' 
    $text2 = 'set timing off'
    $text2 = 'set serveroutput off'
    $text2 | Add-Content 'Deploy_New.ctl' 
    $text2 = 'Select ''Post Deployment user objects : '' || Count(1) from user_objects;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'select ''Post Deployment Invalid objects for user : '' ||sys_context( ''userenv'', ''current_schema'' ) from dual;'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'select object_name,object_type from user_objects where status=''INVALID'';'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'Select * from user_errors Order by Name,Sequence;'
    $text2 | Add-Content 'Deploy_New.ctl'
    
    $text2 = 'spool off'
    $text2 | Add-Content 'Deploy_New.ctl'
    $text2 = 'exit'
    $text2 | Add-Content 'Deploy_New.ctl'
	 
  #if ($respStatusCode -eq 0)
  #{
     sqlplus  cashkotak/cashkotak@//10.10.46.89:1530/fcmsuat "@Deploy_New.ctl"
      
      
    echo $LASTEXITCODE
    if ($LASTEXITCODE -ne 0 )
    { 
    write-host error;
    # Writes an error to the build summary and the log with details about the error
    Write-Error "$("the Write-Error PowerShell command reported that") $($env:ErrorMessage)"
    # Writes an error to the build summary and to the log in red text
    Write-Host  "$("##vso[task.LogIssue type=error;]") $("the task.LogIssue Azure Pipelines logging command reported that") $($env:ErrorMessage)"
    exit $LASTEXITCODE;
    }
    else
    { 
    write-host ok;
    }
  #}
    

    cd ..
}