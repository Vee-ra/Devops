import time
import sys

#method to write logs in file
def log(level, msg):
	dts = time.strftime('%d-%m-%Y %H:%M:%S')
	logFile.write('%s %s - %s\n' % (dts, level, msg))
	
#define log file variables
DEBUG = 'DEBUG'
ERROR = 'ERROR'

# check mandatory parameters are passed in command line
if  len(sys.argv) < 3:
	print 'Mandatory parameters missing [AppName, contextRoot, warFileName, moduleName]'
	logFile = open('/app/IBM/WebSphere/FCMS/error.log', 'w')
	log(ERROR, 'Mandatory parameters missing [AppName, contextRoot, warFileName, moduleName]')
	logFile.close()
	sys.exit()
	#endIf

# Read application parameters passed in command line argument
appName = sys.argv[0]
contextRoot = sys.argv[1]
warFileName = sys.argv[2]
moduleName = sys.argv[3]
	
# change following parameter according to service and environment
mwfAppServer1 = 'FCMClientSrv01'
mwfAppServer2 = 'FCMClientSrv02'
#targetCluster = 'WebSphere:cell=MWFAPP1Cell01,cluster=FrameWorkCluster+WebSphere:cell=MWFAPP1Cell01,node=MWFWEB1-node,server=webserver1+WebSphere:cell=MWFAPP1Cell01,node=MWFWEB2-node,server=webserver2'
#targetCluster = 'WebSphere:cell=Dmgr_Cell01,cluster=Emandate_Cluster+WebSphere:cell=Dmgr_Cell01,node=webservernode1,server=webserver1+WebSphere:cell=Dmgr_Cell01,node=webservernode2,server=webserver2+WebSphere:cell=Dmgr_Cell01'
targetCluster = 'WebSphere:cell=CellDmgr1,node=kbudvmla00272,server=webserver1+WebSphere:cell=CellDmgr1,cluster=FCMS_Cluster'
URI = warFileName+',WEB-INF/web.xml'


# Define log file name
logFileName = '/app/IBM/WebSphere/FCMS/'+contextRoot+'.log'
	
try:
	# open log file in write mode
	logFile = open(logFileName, 'w')
	print 'Command line arguments are: appName= ['+appName+'], contextRoot = ['+contextRoot+'], moduleName =['+moduleName+']'	
	log(DEBUG, 'Command line arguments are: appName= ['+appName+'], contextRoot = ['+contextRoot+'], moduleName =['+moduleName+']')
	
	try:
		# Get application manager of MWF AppServer 1
		print 'Getting Application Manager @'+mwfAppServer1+' ...'
		log(DEBUG, 'Getting Application Manager @'+mwfAppServer1+' ...')
		appManagerAppServer1 = AdminControl.queryNames('type=ApplicationManager,process='+mwfAppServer1+',*')
		
		# Get application manager of MWF AppServer 2
		print 'Getting Application Manager @'+mwfAppServer2+' ...'
		log(DEBUG, 'Getting Application Manager @'+mwfAppServer2+' ...')
		appManagerAppServer2 = AdminControl.queryNames('type=ApplicationManager,process='+mwfAppServer2+',*')
	except:
		print "Unexpected error while Getting Application Manager: ", sys.exc_info()[0], sys.exc_info()[1]
		log(ERROR, 'Unexpected error while Getting Application Manager')		
	else:
		# If application is already installed then unintsall application
		if AdminApplication.checkIfAppExists(appName) == 'true':
			# Stop service On MWF AppServer 1
			print 'Stopping ['+appName+'] on '+mwfAppServer1+'...'
			log(DEBUG, 'Stopping ['+appName+'] on '+mwfAppServer1+'...')
			try:
				AdminControl.invoke(appManagerAppServer1, 'stopApplication', appName);
				print '['+appName+'] stopped on ' + mwfAppServer1 + '...'
				log(DEBUG, '['+appName+'] stopped on ' + mwfAppServer1 + '...')
			except:
				print '['+appName+'] not running on ' + mwfAppServer1 + '...'
				log(DEBUG, '['+appName+'] not running on ' + mwfAppServer1 + '...')
				
			# Stop service On MWF AppServer 2
			print 'Stopping ['+appName+'] on '+mwfAppServer2+'...'
			log(DEBUG, 'Stopping ['+appName+'] on '+mwfAppServer2+'...')
			try:
				AdminControl.invoke(appManagerAppServer2, 'stopApplication', appName);
				print '['+appName+'] stopped on '+mwfAppServer2+'...'
				log(DEBUG, '['+appName+'] stopped on '+mwfAppServer2+'...')
			except:
				print '['+appName+'] not running on '+mwfAppServer2+'...'
				log(DEBUG, '['+appName+'] not running on ' + mwfAppServer2 + '...')

			# Uninstall the application
			print 'uninstalling ['+appName+'] ...'
			log(DEBUG, 'uninstalling ['+appName+'] ...')
			AdminApp.uninstall(appName);
			AdminConfig.save();
			print '['+appName+'] is uninstalled ...'
			log(DEBUG, '['+appName+'] is uninstalled ...')
			
			# install the application
			print 'installing ['+appName+'] ...'
			log(DEBUG, 'installing ['+appName+'] ...')
			AdminApp.install('/app/IBM/WebSphere/FCMS/war_path/'+warFileName, ['-appname', appName, '-contextroot', contextRoot,  '-usedefaultbindings', '-defaultbinding.virtual.host', 'default_host', '-target', targetCluster, '-MetadataCompleteForModules', [[moduleName, URI, 'true']]])
			AdminConfig.save();
			print '['+appName+'] is installed ...'
			log(DEBUG, '['+appName+'] is installed ...')
		else:
			# install the application
			print '['+appName+'] is Not Exists, installing New Application ['+appName+'] ...'
			log(DEBUG, '['+appName+'] is Not Exists, installing New Application ['+appName+'] ...')
			AdminApp.install('/app/IBM/WebSphere/FCMS/war_path/'+warFileName, ['-appname', appName, '-contextroot', contextRoot,  '-usedefaultbindings', '-defaultbinding.virtual.host', 'default_host', '-target', targetCluster, '-MetadataCompleteForModules', [[moduleName, URI, 'true']]])
			AdminConfig.save();
			print 'New Application ['+appName+'] is installed ...'
			log(DEBUG, 'New Application ['+appName+'] is installed ...')
			
		isReady = AdminApp.isAppReady(appName)

		while (isReady=='false'):
			time.sleep(5)
			isReady = AdminApp.isAppReady(appName)

		print '['+appName+'] is installed on Cluster...'
		log(DEBUG, '['+appName+'] is installed on Cluster...')

		# Start Service On MWF AppServer 1
		try:
			print 'Starting ['+appName+'] @'+mwfAppServer1+' ...'
			log(DEBUG, 'Starting ['+appName+'] @'+mwfAppServer1+' ...')
			AdminControl.invoke(appManagerAppServer1, 'startApplication', appName)
			print '['+appName+'] Started @'+mwfAppServer1+' ...'
			log(DEBUG, '['+appName+'] Started @'+mwfAppServer1+' ...')
		except:
			print "Unexpected error: ", sys.exc_info()[0], sys.exc_info()[1]
			log(ERROR, 'Unexpected error: Unable to start application @'+mwfAppServer1)			

		# Start Service On MWF AppServer 2
		try:
			print 'Starting ['+appName+'] @'+mwfAppServer2+' ...'
			log(DEBUG, 'Starting ['+appName+'] @'+mwfAppServer2+' ...')
			AdminControl.invoke(appManagerAppServer2, 'startApplication', appName)
			print '['+appName+'] Started @'+mwfAppServer2+' ...'
			log(DEBUG, '['+appName+'] Started @'+mwfAppServer2+' ...')
		except:
			print "Unexpected error: ", sys.exc_info()[0], sys.exc_info()[1]
			log(ERROR, 'Unexpected error: Unable to start application @'+mwfAppServer2)

except:
	print "Unexpected error: ", sys.exc_info()[0], sys.exc_info()[1]
	log(ERROR, 'Unexpected error: Unable to install application on any of or on both the servers')

print 'Exiting...'	
log(DEBUG, 'Exiting...')
logFile.close()
time.sleep(.500)